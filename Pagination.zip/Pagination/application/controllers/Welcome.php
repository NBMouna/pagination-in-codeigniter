<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

    

    /**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
    
        public function __construct() {
            parent::__construct();
            $this->load->library('form_validation');
            $this->load->model('Dbmodel');
            $this->load->helper(array('form','url'));
             $this->load->library('pagination');
           $this->load->library('upload');
               $this->load->helper(array('form', 'url', 'captcha'));
              

//$this->load->library('email');


           
        }
    
	public function index()
	{
             
                $this->load->view('userheader');
		$this->load->view('about');
                $this->load->view('portfolio');
                $this->load->view('services');
                $this->load->view('testimonal');
                 
                $this->load->view('team');
                $this->load->view('contact');
           
                $this->load->view('userfooter');
                  
	}
        
        
            public function Checkupload(){
      $this->load->view('upload');
      //redirect(base_url() . 'Welcome/CheckUploads');
       }
       
       public function CheckUploads(){
         $this->load->view('uploadsuccess');
        }
         public function CheckAbout()
	{
                 $this->load->view('userheader');
		 $this->load->view('about');
                 $this->load->view('userfooter');
		
	}
        
        
        
        
          public function CheckPortfolio()
	{
                 $this->load->view('userheader');
		 $this->load->view('portfolio');
                 $this->load->view('userfooter');
		
	}
        
        
        public function CheckContact()
	{
            
           
            
        
                 $this->load->view('userheader');
		 $this->load->view('contact');
                 $this->load->view('userfooter');
		
	}
        
       
         
        public function CheckJobSeekersLogin()
	{
                $this->load->view('userheader');
		$this->load->view('jobseekerslogin');
                 $this->load->view('userfooter');
	}
        
         public function CheckLogin()
	{
                $this->load->view('userheader');
		$this->load->view('login');
                 $this->load->view('userfooter');
	}
        
        
         public function CheckClientLogin()
	{
                $this->load->view('userheader');
		$this->load->view('clientlogin');
                $this->load->view('userfooter');

	}
        
         public function CheckJobs()
	{
                $this->load->view('userheader');
		$this->load->view('jobs');
                $this->load->view('userfooter');
	}
        
         public function CheckUserLogin()
          {
       $manageremail=$this->input->post('email');
       $managerpwd=  $this->input->post('password');   
      $this->load->model('user');
       $managerData= $this->user->employeelogin($manageremail,$managerpwd);
       if(empty($managerData))
          {
             $this->session->set_flashdata('status2','Please Login with Valid username and password ');
             redirect(base_url() . 'Welcome/CheckLogin');    
          }
         else{
                $data['managerInfo']= $managerData;    
                $this->load->view('managerhomepage',$data); 
          }
          redirect(base_url() . 'Welcome/CheckJobs');  
               }
               
        public function CheckManagerLogin()

	{

             $this->load->view('managerlogin');

         }
         
          public function CheckEmployeeLogin()
          {
       $manageremail=$this->input->post('email');
       $managerpwd=  $this->input->post('password');   
      $this->load->model('Dbmodel');
       $managerData= $this->Dbmodel->employeelogin($manageremail,$managerpwd);
       if(empty($managerData))
          {
             $this->session->set_flashdata('status2','Please Login with Valid username and password ');
             redirect(base_url() . 'Welcome/CheckManagerLogin');    
          }
         else{
                $data['managerInfo']= $managerData;    
                $this->load->view('managerhomepage',$data); 
          }
               }
               
               
         public function InsertContact()
        {
       
        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('<div class="error">', '</div>');
            $this->form_validation->set_rules('name', 'Name', 'trim|required');
           $this->form_validation->set_rules('number', 'Number', 'trim|required|min_length[10]|max_length[12]');
           $this->form_validation->set_rules('mail', 'Email', 'required|valid_email|is_unique[users.email],',
                    array(
               
                'is_unique'     => 'This Email ID already exists.'
        ));
            $this->form_validation->set_rules('msg', 'Message', 'trim|required');
            if ($this->form_validation->run() == FALSE)
                {
                $this->load->view('userheader');
                $this->load->view('contact');
                $this->load->view('userfooter');
                
                }
                else
                {
               
		 $name= $this->input->post('name');
        
      $number= $this->input->post('number');
        

        $email= $this->input->post('mail');
        
          $msg= $this->input->post('msg');
          $document= $this->input->post('userfile');

      
        $this->load->model('Dbmodel');

        $this->Dbmodel->insertcontact($name,$number,$email,$msg,$document);

        $this->session->set_flashdata('status','Sent Successfully');

        redirect(base_url() . 'Welcome/CheckContact');
                }
   
        }
    
 
 
       
         public function CheckManagerContactEnquery()
	{
               
             
              $this->load->model('Dbmodel');

                $successdata= $this->Dbmodel->displaycontact();

                $data['viewmanagerdonate']=$successdata; 
                
				// pagination starts from here

                $allrecord = $this->Dbmodel->allrecord();
		$baseurl =  base_url().$this->router->class.'/'.$this->router->method;
		
	    $paging=array();
		$paging['base_url'] =$baseurl;
		$paging['total_rows'] = $allrecord;
		$paging['per_page'] = 5;
		$paging['uri_segment']= 3;
		$paging['num_links'] = 2;
		$paging['first_link'] = 'First';
		$paging['first_tag_open'] = '<li>>';
		$paging['first_tag_close'] = '</li>';
		$paging['num_tag_open'] = '<li>';
		$paging['num_tag_close'] = '</li>';
		$paging['prev_link'] = 'Prev';
		$paging['prev_tag_open'] = '<li>';
		$paging['prev_tag_close'] = '</li>';
		$paging['next_link'] = 'Next';
		$paging['next_tag_open'] = '<li>';
		$paging['next_tag_close'] = '</li>';
		$paging['last_link'] = 'Last';
		$paging['last_tag_open'] = '<li>';
		$paging['last_tag_close'] = '</li>';
		$paging['cur_tag_open'] = '<li class="active"><a href="javascript:void(0);">';
		$paging['cur_tag_close'] = '</a></li>';
		$paging['page_query_string'] = FALSE;
		$this->pagination->initialize($paging);	
		
		$data['limit'] = $paging['per_page'];
		$data['number_page'] = $paging['per_page']; 
        $data['offset'] = ($this->uri->segment(3)) ? $this->uri->segment(3):'0';	
        $data['nav'] = $this->pagination->create_links();
    
		$data['viewmanagerdonate'] = $this->Dbmodel->data_list($data['limit'],$data['offset']);
		
                
                
                //pagination ends here
                
    $this->load->view('managercontactenquery',$data);
   
     
            $this->load->library('zip');
        
        
        
           
    }
              
        
        public function CheckUserContactEnquery()
	{
               
             
              $this->load->model('user');

                $successdata= $this->user->displaycontact();

                $data['viewmanagerdonate']=$successdata; 
                
                
		$this->load->view('usercontactenquery',$data);
                
	}
        
        
        // add new data to database
  public  function usercontactenquery()
        {
           
            $name= $this->input->post('name');
            
           $phone= $this->input->post('phone');
            $email= $this->input->post('email');
            //$msg= $this->input->post('msg');
             $gender= $this->input->post('gender');
            $save =array('name'=>$name,'phone'=>$phone,'email'=>$email,'gender'=>$gender);
           
            $this->load->model('user');
            $this->user->add($save);
            
             redirect(base_url() . 'Welcome/CheckUserContactEnquery');
        }        
        
         //ends here
    
         // add new data to database
        public  function managercontactenquery()
        {
           
            $name= $this->input->post('name');
            
           $number= $this->input->post('number');
            $email= $this->input->post('email');
            $msg= $this->input->post('msg');
            
            $save =array('name'=>$name,'number'=>$number,'email'=>$email,'msg'=>$msg);
           
            $this->load->model('Dbmodel');
            $this->Dbmodel->add($save);
            
             redirect(base_url() . 'Welcome/CheckManagerContactEnquery');
        }        
        
         //ends here
    
        
    public  function delete()
{
        
  
        $this->load->model('Dbmodel');
        $id = $this->input->get('id');
        if($this->Dbmodel->deleteuser($id))
        {
            $data['data']= $this->Dbmodel->getuser();
            $this->load->view('managercontactenquery',$data);
        }
         redirect(base_url() . 'Welcome/CheckManagerContactEnquery');
        
}
 
public  function UserDelete()
{
        
  
        $this->load->model('user');
        $id = $this->input->get('id');
        if($this->user->deleteuser($id))
        {
            $data['data']= $this->user->getuser();
            $this->load->view('usercontactenquery',$data);
        }
         redirect(base_url() . 'Welcome/CheckUserContactEnquery');
        
}
 /*
     * User registration
     */
    public function registration(){
        
       // $id= $this->input->post('id');
         $name= $this->input->post('name');
        
     
        

        $email= $this->input->post('email');
         $phone= $this->input->post('phone');
        
          $password= $this->input->post('password');
       //  $conf_password= $this->input->post('conf_password');
          $gender= $this->input->post('gender');

      
        $this->load->model('user');

        $this->user->insertusers($name,$email,$phone,$password,$gender);

		

        $this->session->set_flashdata('status','Sent Successfully');

       
         redirect(base_url() . 'Welcome/CheckJobSeekersLogin');
    }
    
    


	
	// View each data
	        
              public function show_detail(){
                               $id= $this->input->get('link_id');
                               $result['viewmanagerdonate']= $this->Dbmodel->show_detail($id);
                               $this->load->view("show_detail",$result);
                           }
     public function get_value()
     {
         $data['viewmanagerdonate']= $this->Dbmodel->get_data();
         $this->load->view('managercontactenquery',$data);
     }
     
     //View data ends here
     
     // View each data
	        
              public function usershow_detail(){
                               $id= $this->input->get('link_id');
                               $result['viewmanagerdonate']= $this->user->show_detail($id);
                               $this->load->view("usershowdetail",$result);
                           }
     public function userget_value()
     {
         $data['viewmanagerdonate']= $this->user->get_data();
         $this->load->view('usercontactenquery',$data);
     }
     
     //View data ends here
     
     
     public function edit()
    {
        
            $id = $this->input->get('id');
       $this->load->model('Dbmodel');
             $data['viewmanagerdonate']= $this->Dbmodel->getuserbyid($id);
              $this->load->view("edit",$data);
            //echo "success";
        }
        
        public function update()
        {
            $id= $this->input->post('id');
            $name= $this->input->post('name');
            $number= $this->input->post('number');
            //$Email= $this->input->post('email');
            $data=array('name'=>$name,'number'=>$number);
          if($this->Dbmodel->updatebyid($data,$id))
          {
              $data['viewmanagerdonate']= $this->Dbmodel->displaycontact();
              $this->load->view('show_detail',$data);
          }
            redirect(base_url() . 'Welcome/CheckManagerContactEnquery');
        }
        public function valid() {
              
            $this->load->library('form_validation');
           $this->form_validation->set_error_delimiters('<div class="error">', '</div>');
            $this->form_validation->set_rules('name', 'Name', 'trim|required');
            $this->form_validation->set_rules('number', 'Number', 'trim|required|min_length[10]|max_length[12]');
             $this->form_validation->set_rules('email', 'Email', 'required|is_unique[users.email]');
            if ($this->form_validation->run() == FALSE)
                {
                  $this->session->set_flashdata('error', validation_errors());
                  $this->load->view('upload');
                }
                else
                {
                        echo "success";
                }
        }
        
        
       
       
        public function Checkuserprofile(){
           
    
if ( $this->session->userdata('login') )
    {

        $session_data = $this->session->userdata('sessiondata');
        $id = $session_data['viewmanagerdonate_id'];
        $this->load->model('user');
        $result = $this->user->get_user_data($id);

        if($result==0)
        {
            echo 'No user Found';
        }
        else
        {
            $data['user']=$result;
            $this->load->view('header');
            
        }
    }
       
        $this->load->model('user');
        //$result = $this->user->get_user_data($id);

        $this->load->view("userprofile", $data);
        
           
           
        }
  
            
      //redirect(base_url() . 'Welcome/CheckUploads');
       
         

       
       public function user_logout(){
 
  $this->session->sess_destroy();
  redirect('Welcome/index', 'refresh');
}
       public function CheckImage(){
           	
  
   $this->load->view('image');
}
        public function Checkajax(){
            
           	
   $this->load->model('imgmodel');
   $this->load->view('ajaxsearch');
   
}


 
     
        
        
        
	public function Useredit()
    {
        
            $id = $this->input->get('id');
       $this->load->model('user');
             $data['viewmanagerdonate']= $this->user->getuserbyid($id);
              $this->load->view("useredit",$data);
            //echo "success";
        }
         public function Userupdate()
        {
            $id= $this->input->post('id');
            $name= $this->input->post('name');
            $number= $this->input->post('number');
            //$Email= $this->input->post('email');
            $data=array('name'=>$name,'number'=>$number);
          if($this->Dbmodel->updatebyid($data,$id))
          {
              $data['viewmanagerdonate']= $this->Dbmodel->displaycontact();
              $this->load->view('show_detail',$data);
          }
            redirect(base_url() . 'Welcome/CheckUserContactEnquery');
        }
}



   
     
             




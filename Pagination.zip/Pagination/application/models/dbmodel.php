   <?php
class Dbmodel extends CI_Model {

    function __construct(){
	parent::__construct();	
		$this->load->library(array('session','cart','pagination'));
		$this->load->library('');
		$this->load->helper('url');
		$this->load->database();	
    }


    public function employeelogin($manageremail,$managerpwd)
    {
                $this->db->where('user',$manageremail);
		$this->db->where('password',$managerpwd);
                $query=$this->db->get('user');
                return $query->result();
        
    }
    
     public function insertcontact($name,$number,$email,$msg,$document)
        {
  $sql="insert into contact(`name`,`number`,`Email`,`msg`,`document`) VALUES ('$name','$number','$email','$msg','$document')";
                   $this->db->query($sql);
        }
        
        
         
public function displaycontact()
    {
           $query=$this->db->get('contact');
	   return $query->result();  
    }
    
    public function getuserbyid($id)
    {
        $this->load->database();
         $this->db->where('id', $id);
           $data=$this->db->get('contact');
	   return $data->result();  
    }
    
    
    public function updatebyid($data,$id)
    {
        $this->load->database();
         $this->db->where('id', $id);
         $this->db->update('contact', $data);
           
	   return true;  
    }
  
    public function add($data)
  {
  {
     
      $this->db->insert('contact',$data);
      $id= $this->db->insert_id();
  }
      
          return $id;    
      
  }
  
   
  
 
public function deleteuser($id)
  {

      $this->db->where('id', $id);
      $this->db->delete('contact'); 
  }
  
  // Pagination starts from here
  public function allrecord(){
		
		$this->db->select('*');
		$this->db->from('contact');
		$rs = $this->db->get();
		return $rs->num_rows();
	}
	
	public function data_list($limit,$offset){
		
		$this->db->select('*');
		$this->db->from('contact');
		$this->db->order_by('id','desc');
		$this->db->limit($limit,$offset);
		$rs = $this->db->get();
		return $rs->result_array();
	}
	//Pagination ends here
        
        //view data
public function show_detail($id)  
      {  
           $this->db->where('id', $id);  
           $query = $this->db->get("contact");  
          return $query->result();  
      }  
      
      public function get_data()
      {
          $query = $this->db->query("SELECT * FROM contact");
           return $query->result(); 
      }
      
      
      //ends here
      
       public function editCrud($id)
    {
        $update = array(
            'name' => $this->input->post('name'),
            'email' => $this->input->post('Email'),
            'number' => $this->input->post('number')
            );
        $this->db->where('id',$id);
        return $this->db->update('contact', $update);
    }
    
    
    
}
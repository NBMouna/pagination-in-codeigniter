<!DOCTYPE html>
<html lang="en">
<head>
  <title>SmartJobs</title>
  <meta charset="utf-8">
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="shortcut icon" href="<?php echo base_url();?>./img/logo1.jpg" type="image/x-icon">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
 <script src="<?php echo base_url();?>https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="<?php echo base_url();?>https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <link rel='stylesheet' href='<?php echo base_url();?>https://use.fontawesome.com/releases/v5.6.3/css/all.css' integrity='sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/' crossorigin='anonymous'>
		<link rel="stylesheet" href="<?php echo base_url();?>https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<script src="<?php echo base_url();?>js/my_js.js"></script>
</head>
<style>
table {
     border: 1px solid #dddddd;
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
    
    border: 1px solid #dddddd;
  background-color: #dddddd;
}
</style>
<style>
img#close {
position:absolute;
right:-30px;
top:-6px;
height:30px;
cursor:pointer;
background-color: window; 
}

form {
max-width:500px;
min-width:250px;
padding:10px 50px;
border:2px solid gray;
border-radius:10px;
font-family:raleway;
background-color:lightslategray;
}

#submit {
text-decoration:none;
width:100%;
height:900%;
text-align:center;
display:block;

background-color:#FFBC00;
color:#fff;
border:1px solid #FFCB00;
padding:10px 0;
font-size:20px;
cursor:pointer;
border-radius:5px
}
    
#abc {
width:100%;
height:100%;
opacity:.95;
top:0;
left:0;
display:none;
position:fixed;
background-color:#313131;
overflow:auto
}

div#popupContact {
position:absolute;
left:50%;
top:17%;
margin-left:-202px;
font-family:'Raleway',sans-serif
}

p {
margin-top:30px
}
h2 {
background-color:lightslategray;
padding:20px 35px;
margin:-10px -50px;
text-align:center;
border-radius:10px 10px 0 0
}
hr {
margin:10px -50px;
border:0;
border-top:1px solid #ccc
}
input[type=text] {
width:90%;
padding:8px;
margin-top:30px;
border:1px solid #ccc;
padding-left:50px;
font-size:14px;
font-family:raleway
}
#name {
background-image:url(../images/name.jpg);
background-repeat:no-repeat;
background-position:5px 7px
}



textarea {
background-image:url(../images/msg.png);
background-repeat:no-repeat;
background-position:5px 7px;
width:230px;
height:80px;
padding:10px;

margin-top:10px;
border:1px solid #ccc;
margin-left:20px;

font-size:16px;
font-family:raleway;
margin-bottom:30px
}
#submit {
text-decoration:none;
width:100%;
height:900%;
text-align:center;
display:block;

background-color:#FFBC00;
color:#fff;
border:1px solid #FFCB00;
padding:10px 0;
font-size:20px;
cursor:pointer;
border-radius:5px
}
span {
color:white;
font-weight:100
}
button {
width:20%;
height:50px;
border-radius:3px;
background-color:#cd853f;
color:#fff;
font-family:'Raleway',sans-serif;
font-size:18px;
cursor:pointer
    
}
</style>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">SmartJobs</a>
    </div>
    <ul class="nav navbar-nav">
     <!-- <li class="active"><a href="#">Home</a></li>-->
      <li class="active"><a href="<?php echo base_url();?>Welcome/CheckManagerContactEnquery">Enquiry</a></li>
      
      <li class="active"><a href="<?php echo base_url();?>Welcome/CheckUserContactEnquery">JobSeekers Login</a></li>
      
    <!--  <li class="active"><a href="<?php echo base_url();?>Welcome/CheckManagerContactEnquery">Client Login </a></li>
<!--      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Page 1 <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="#">Page 1-1</a></li>
          <li><a href="#">Page 1-2</a></li>
          <li><a href="#">Page 1-3</a></li>
        </ul>
      </li>-->
   </ul>
    <ul class="nav navbar-nav navbar-right">
        <br>  <a href="<?php echo base_url();?>" class="btn btn-info btn-sm">
           <span class="glyphicon glyphicon-log-in"></span> LOGOUT
        </a>&nbsp;<br/>
     <!-- <li><a href="<?php echo base_url();?>"<span class="glyphicon glyphicon-log-in"></span> LOGOUT</a></li>-->
    </ul>
  </div>
</nav>
  
 
    
    <div class="container">

        

   

        <center>  <h3> <b> Enquiry Details </b> </h3> </center>

   <center> <font color="red"> <?php echo $this -> session->flashdata("status"); ?></font></center>
   
 
 
 
 <div id="abc">
<!-- Popup Div Starts Here -->
<div id="popupContact">
<!-- Contact Us Form -->
   <center>Add user </center>
   <form action="<?php echo base_url();?>Welcome/managercontactenquery"  method="post" enctype="multipart/form-data" id="form" name="form">
 <img id="close" src="<?php echo base_url();?>img/close.png" alt="close" onclick ="div_hide()">
      <hr>
      <h2>Add User Details</h2>
<i class="glyphicon glyphicon-user"> </i> <input id="name" name="name" placeholder="Name" type="text"><br>
<i class="glyphicon glyphicon-phone"></i> <input id="number" name="number" placeholder="Number" type="text"><br>
<i class="glyphicon glyphicon-envelope"></i> <input id="email" name="email" placeholder="Email" type="text"><br><br>
<i class='fas fa-comment-dots'></i>   <textarea id="msg" name="msg" placeholder="Message"></textarea>
 <br>  <a href="javascript:%20check_empty()" name="add" id="submit">submit</a>
    <!--  <input type="Submit" id="submit" name="add" value="Add">-->
</form>
</div>
<!-- Popup Div Ends Here -->
</div>
   <br><br><br>
   <button id="popup" onclick="div_show()">Add User</button> <br>
   <br><br><br>
   
   
   
   
   
   
  <table class="table">

    <thead>

     

        <tr>
            
  
         <th>Id</th>

        <th>Name</th>
           
       <th>Number</th>

        <th>Email</th>

        <th>Message</th>
        
        <!--<th>Date & Time</th>-->
       

        <th>View</th>
        
        
         <th>Edit</th>
        
 <th>Delete</th>
         
<th>Document</th>
         
        </tr>

     

    </thead>
  

    <tbody>
         
        

  <?php foreach($viewmanagerdonate as $item){?>

      <tr>
          
          
       <td> <?php echo $item["id"]; ?></td>
       
       <td> <?php echo $item["name"]; ?></td>
    
         <td> <?php echo $item["number"]; ?></td>

          <td><?php echo $item["Email"]; ?></td>

          <td><?php echo $item["msg"]; ?></td>
          
        <!--   <td><?php echo $item->sub_dat; ?></td>-->
           <td>  <a href="<?php echo base_url();?>Welcome/show_detail/?link_id=<?php echo $item["id"];?>">View</a></td>
          
       <td><a href="<?php echo base_url();?>Welcome/edit/?id=<?php echo $item["id"];?>">Edit</a>
  
        <td><a href="<?php echo base_url();?>Welcome/delete/?id=<?php echo $item["id"];?>">Delete</a>
        <td><a href="<?php echo base_url();?>Welcome/CheckImage" alt="image">File</a>
        
      

 
 <?php }?>  
    </tbody>

    </table>
 </div>
        
  <!-- render pagination links 

    
  </div>
 <!-- <p class="footer">Page rendered in <strong>{elapsed_time}</strong> seconds</p>-->
 </div>
  <style>
.pagination-dive li {
    list-style: none;
    display: inline-block;
}
.pagination-dive a:hover, .pagination-dive .active a {
    background: #040404;
}

.pagination-dive a {
    display: inline-block;
    height: initial;
    background: #939890;
    padding: 10px 15px;
    border: 1px solid #fff;
    color: #fff;
}
</style>
  
  <div class="pagination-dive" >
<?php echo $nav; ?>
</div>
  
</div>




</body>
</html>


  
  
  
  
  
  
  
  

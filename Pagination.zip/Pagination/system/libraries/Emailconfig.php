
<?php
class CI_Email {
public function Emailconfig() {


define('GUSER', ''); // email address
        define('GPWD', ''); // email password
        define('HOST', 'smtp.gmail.com'); // email server host
        define('PORT','465' ); // email server port
        /**
         * Gmail host smtp.gmail.com
         * Gmail port 465
         */
}}
        ?>